import express from 'express';
import { getPromotions, addPromotion, updatePromotion, deletePromotion } from '../controllers/promotionController.js';

const router = express.Router();

router.get('/', getPromotions);
router.post('/add', addPromotion);
router.put('/:id', updatePromotion);
router.delete('/:id', deletePromotion);

export default router;
